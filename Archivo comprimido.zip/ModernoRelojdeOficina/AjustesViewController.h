//
//  AjustesViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TimeWorldViewController.h"
#import <AudioToolbox/AudioToolbox.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MediaToolbox/MediaToolbox.h>


@class TimeWorldViewController;


@protocol ajustesViewControllerDelegate;

@class SonidoViewController;
@interface AjustesViewController : UITableViewController<UITextViewDelegate,UINavigationControllerDelegate,
UIImagePickerControllerDelegate, NSURLConnectionDelegate,AUAudioUnitFactory,NSUserActivityDelegate,MPPlayableContentDataSource>{
    id delegateAjuste;

    NSString*timeViewControllerNibName;
    UILabel *detailDescriptionLabel;

    
}

@property (strong, nonatomic) TimeWorldViewController *detailViewController;

-(IBAction) guardaDatos;

@property (nonatomic, assign) int time;
@property (nonatomic, assign) BOOL vibrate;
@property (nonatomic, assign) float volume;

@property NSUserDefaults *userDefaults;



// SETINGS SOS //
@property (nonatomic, retain) IBOutlet UITableViewCell*enableCell;
@property (nonatomic, retain) IBOutlet UISwitch*enableSwitch;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableSOSOn;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableSOSOFF;



// SETINGS VIBRAR //
@property (nonatomic, retain) IBOutlet UITableViewCell*VibrarCell;
@property (nonatomic, retain) IBOutlet UISwitch*VibrarSwitch;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableOnVibrar;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableOFFVibrar;

// SETINGS UPDATES //
@property (nonatomic, retain) IBOutlet UITableViewCell*UpdatesCell;
@property (nonatomic, retain) IBOutlet UISwitch*UpdatesSwitch;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableOnUpdates;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableOFFUpdates;


// SETINGS SOUNDS //
@property (nonatomic, retain) IBOutlet UITableViewCell*SoundCell;
@property (nonatomic, retain) IBOutlet UILabel*soundMINLabel;
@property (nonatomic, retain) IBOutlet UILabel*soundMAXLabel;
@property (nonatomic, retain) IBOutlet UISlider*volumeSlider;



// SETINGS LOCATIONS //
@property (nonatomic, retain) IBOutlet UITableViewCell*LocationsCell;
@property (nonatomic, retain) IBOutlet UISwitch*LocationsSwitch;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableLocationsON;
@property (nonatomic, retain) IBOutlet UILabel*LblEnableLocationsOFF;

///////////////

// SETINGS TIME CLOCK WORLD //
@property (nonatomic, retain) IBOutlet UITableViewCell*TimeWordlCell;



- (void)sonidoViewController: (SonidoViewController *)controller
             didSelectSonido:(NSString *)sonido;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil timeViewControllerNibName:(NSString*)aName;

- (IBAction)ActivarSOS:(id)sender;
- (IBAction)ActivarVibrar:(id)sender;
- (IBAction)ActivarUpdates:(id)sender;
- (IBAction)Volumen:(UISlider *)sender;
- (IBAction)ActivarLocations:(id)sender;
    


@property (nonatomic, retain) id delegateAjuste;




@property (strong, nonatomic) IBOutlet UIBarButtonItem *BtnSave;





@property (nonatomic) IBOutlet UIActivityIndicatorView *loadingProgressIndicator;

@property (retain, nonatomic) IBOutletCollection(UILabel) NSArray *arrayOfLabels;

@property (nonatomic, retain) NSManagedObjectContext *context;


@end

@protocol ajustesViewControllerDelegate

- (void) metodoAjuste;

@end
