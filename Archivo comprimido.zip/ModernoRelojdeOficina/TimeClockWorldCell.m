//
//  CatalanCell.m
//  MultiJugadoresJuegodelHorcado
//
//  Created by Hackermaster on 09/05/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "TimeClockWorldCell.h"

@implementation TimeClockWorldCell

@synthesize LblTimeClockWorld = _LblTimeClockWorld;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.LblTimeClockWorld.text = _LblTimeClockWorld;
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
