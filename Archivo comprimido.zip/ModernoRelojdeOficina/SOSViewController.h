//
//  SOSViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "CoreLocationController.h"

#import <CallKit/CallKit.h>
#import <CoreSpotlight/CoreSpotlight.h>
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>



@interface SOSViewController : UIViewController <MKMapViewDelegate,MKLocalSearchCompleterDelegate,CoreLocationControllerDelegate>{
    
    MKMapView *mapView;
    UIToolbar *toolBar;
    MKPointAnnotation *annotationPoint;
    MKMapPoint *point;
    CLLocationManager *locManager;
}


@property (nonatomic, retain) IBOutlet UIWebView *viewWeb;


@property (nonatomic, retain) IBOutlet UILabel *LblCallEmergecies;
@property (nonatomic, retain) IBOutlet UILabel *LblLatitud;
@property (nonatomic, retain) IBOutlet UILabel *LbLong;

@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *ConectingView;

@property (nonatomic, retain) IBOutlet MKMapView *Localizacion;
@property (strong, nonatomic) IBOutlet UIToolbar *toolBar;

@property (nonatomic) MKMapPoint *point;
@property (nonatomic, retain) CoreLocationController *locationController;
@end
