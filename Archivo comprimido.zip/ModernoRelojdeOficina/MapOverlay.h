//
//  MapOverlay.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 26/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface MapOverlay : NSObject <MKOverlay> {
    
}

- (MKMapRect)boundingMapRect;

@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;

@end
