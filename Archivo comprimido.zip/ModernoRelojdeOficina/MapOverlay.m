//
//  MapOverlay.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 26/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "MapOverlay.h"


@implementation MapOverlay

-(CLLocationCoordinate2D)coordinate {
    
    return CLLocationCoordinate2DMake(40.8124466, -0.5214339000000336);
    
  
}



@end
