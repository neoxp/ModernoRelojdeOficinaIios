//
//  ListaAlarmasTableViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 27/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "ListaAlarmasTableViewController.h"
#import "sonidosViewController.h"
#import "Settings.h"
#import "insist.h"
#import "EditAlarmTableViewController.h"
#import "EditAlarmTableViewController.h"

@interface ListaAlarmasTableViewController (){}

@end


@implementation ListaAlarmasTableViewController
{
    NSArray *sonidos;
    NSUInteger indiceSeleccionado;
}

// hora 1
@synthesize Alarmaenabled1Cell, Alarmaenabled1CellSwitch, AlarmaenabledCell, lblHoraAlarma1, lblHoraAlarmaActivada, lblHoraAlarmaDesactivada;

// hora 2
@synthesize Alarmaenabled2Cell, Alarmaenabled2CellSwitch, EnabledAmarla2Cell, lblHoraAlarma2, lblHoraAlarmaActivada2, lblHoraAlarmaDesactivada2;

// hora 3
@synthesize Alarmaenabled3Cell, Alarmaenabled3CellSwitch, EnabledAmarla3Cell, lblHoraAlarma3, lblHoraAlarmaActivada3, lblHoraAlarmaDesactivada3;

// hora 4
@synthesize Alarmaenabled4Cell, Alarmaenabled4CellSwitch, EnabledAmarla4Cell, lblHoraAlarma4, lblHoraAlarmaActivada4, lblHoraAlarmaDesactivada4;


// hora 5
@synthesize Alarmaenabled5Cell, Alarmaenabled5CellSwitch, EnabledAmarla5Cell, lblHoraAlarma5, lblHoraAlarmaActivada5, lblHoraAlarmaDesactivada5;






- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad{
    
    
    [super viewDidLoad];
    
    [Alarmaenabled1CellSwitch setOn:NO];
    [Alarmaenabled2CellSwitch setOn:NO];
    [Alarmaenabled3CellSwitch setOn:NO];
    [Alarmaenabled4CellSwitch setOn:NO];
    [Alarmaenabled5CellSwitch setOn:NO];
    
    
    // hora 1 //
    lblHoraAlarma1.textColor = [UIColor blackColor];
    
    lblHoraAlarmaActivada.textColor = [UIColor greenColor];
    lblHoraAlarmaDesactivada.textColor = [UIColor redColor];
    
   
    // hora 2 //
    
    lblHoraAlarma2.textColor = [UIColor blackColor];
    
    lblHoraAlarmaActivada2.textColor = [UIColor greenColor];
    lblHoraAlarmaDesactivada2.textColor = [UIColor redColor];
    
    // hora 3 //
    lblHoraAlarma3.textColor = [UIColor blackColor];
    
    lblHoraAlarmaActivada3.textColor = [UIColor greenColor];
    lblHoraAlarmaDesactivada3.textColor = [UIColor redColor];
   
    
    // hora 4 //
    lblHoraAlarma4.textColor = [UIColor blackColor];
    
    lblHoraAlarmaActivada4.textColor = [UIColor greenColor];
    lblHoraAlarmaDesactivada4.textColor = [UIColor redColor];

    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Actions



- (IBAction)Activarhora1:(id)sender {
    
   
    
    if (Alarmaenabled1CellSwitch.enabled){
        
        lblHoraAlarma1.textColor = [UIColor blackColor];
        lblHoraAlarma1.text = @"05:45 AM";
     
        
    }
    if  (Alarmaenabled1CellSwitch.on){
        
         lblHoraAlarmaActivada.textColor = [UIColor greenColor];
         lblHoraAlarmaActivada.text = @"Enabled";
        
        Alarmaenabled1CellSwitch.enabled = Alarmaenabled1CellSwitch.enabled = YES;
        Alarmaenabled1CellSwitch.alpha = Alarmaenabled1CellSwitch.alpha = .5;
       
        
    }
     else{
         lblHoraAlarmaDesactivada.textColor = [UIColor redColor];
         lblHoraAlarmaDesactivada.text = @"Disabled";
        
        
        Alarmaenabled1CellSwitch.enabled = Alarmaenabled1CellSwitch.enabled = NO;
        Alarmaenabled1CellSwitch.alpha = Alarmaenabled1CellSwitch.alpha = .5;
       
    }
    [delegateAjuste metodoAjuste];
}



- (IBAction)Activarhora2:(id)sender {

    
    if (Alarmaenabled2CellSwitch.enabled){
        
        lblHoraAlarma2.textColor = [UIColor blackColor];
        lblHoraAlarma2.text = @"06:15 AM";
        
        
    }
    if  (Alarmaenabled2CellSwitch.on){
        
        lblHoraAlarmaActivada2.textColor = [UIColor greenColor];
        lblHoraAlarmaActivada2.text = @"Enabled";
        
        Alarmaenabled2CellSwitch.enabled = Alarmaenabled2CellSwitch.enabled = YES;
        Alarmaenabled2CellSwitch.alpha = Alarmaenabled2CellSwitch.alpha = .5;
        
        
    }
    else{
        lblHoraAlarmaDesactivada2.textColor = [UIColor redColor];
        lblHoraAlarmaDesactivada2.text = @"Disabled";
        
        
        Alarmaenabled2CellSwitch.enabled = Alarmaenabled2CellSwitch.enabled = NO;
        Alarmaenabled2CellSwitch.alpha = Alarmaenabled2CellSwitch.alpha = .5;
    }
    [delegateAjuste metodoAjuste];
}

- (IBAction)Activarhora3:(id)sender {
   
    
    
    if (Alarmaenabled3CellSwitch.enabled){
        
        lblHoraAlarma3.textColor = [UIColor blackColor];
        lblHoraAlarma3.text = @"09:30 AM";
        
        
    }
    if  (Alarmaenabled3CellSwitch.on){
        
        lblHoraAlarmaActivada3.textColor = [UIColor greenColor];
        lblHoraAlarmaActivada3.text = @"Enabled";
        
        Alarmaenabled3CellSwitch.enabled = Alarmaenabled3CellSwitch.enabled = YES;
        Alarmaenabled3CellSwitch.alpha = Alarmaenabled3CellSwitch.alpha = .5;
        
        
    }
    else{
        lblHoraAlarmaDesactivada3.textColor = [UIColor redColor];
        lblHoraAlarmaDesactivada3.text = @"Disabled";
        
        
        Alarmaenabled3CellSwitch.enabled = Alarmaenabled3CellSwitch.enabled = NO;
        Alarmaenabled3CellSwitch.alpha = Alarmaenabled3CellSwitch.alpha = .5;
    }
    [delegateAjuste metodoAjuste];
}


- (IBAction)Activarhora4:(id)sender{
    
    if (Alarmaenabled4CellSwitch.enabled){
        
        lblHoraAlarma4.textColor = [UIColor blackColor];
        lblHoraAlarma4.text = @"14:20 PM";
        
        
    }
    if  (Alarmaenabled4CellSwitch.on){
        
        lblHoraAlarmaActivada4.textColor = [UIColor greenColor];
        lblHoraAlarmaActivada4.text = @"Enabled";
        
        Alarmaenabled4CellSwitch.enabled = Alarmaenabled4CellSwitch.enabled = YES;
        Alarmaenabled4CellSwitch.alpha = Alarmaenabled4CellSwitch.alpha = .5;
        
        
    }
    else{
        lblHoraAlarmaDesactivada4.textColor = [UIColor redColor];
        lblHoraAlarmaDesactivada4.text = @"Disabled";
        
        
        Alarmaenabled4CellSwitch.enabled = Alarmaenabled4CellSwitch.enabled = NO;
        Alarmaenabled4CellSwitch.alpha = Alarmaenabled4CellSwitch.alpha = .5;
    }
    [delegateAjuste metodoAjuste];
}



- (IBAction)Activarhora5:(id)sender{
    
    if (Alarmaenabled5CellSwitch.enabled){
        
        lblHoraAlarma5.textColor = [UIColor blackColor];
        lblHoraAlarma5.text = @"18:15 PM";
        
        
    }
    if  (Alarmaenabled5CellSwitch.on){
        
        lblHoraAlarmaActivada5.textColor = [UIColor greenColor];
        lblHoraAlarmaActivada5.text = @"Enabled";
        
        Alarmaenabled5CellSwitch.enabled = Alarmaenabled5CellSwitch.enabled = YES;
        Alarmaenabled5CellSwitch.alpha = Alarmaenabled5CellSwitch.alpha = .5;
        
        
    }
    else{
        lblHoraAlarmaDesactivada5.textColor = [UIColor redColor];
        lblHoraAlarmaDesactivada5.text = @"Disabled";
        
        
        Alarmaenabled5CellSwitch.enabled = Alarmaenabled5CellSwitch.enabled = NO;
        Alarmaenabled5CellSwitch.alpha = Alarmaenabled5CellSwitch.alpha = .5;
    }
    [delegateAjuste metodoAjuste];
}





@end

