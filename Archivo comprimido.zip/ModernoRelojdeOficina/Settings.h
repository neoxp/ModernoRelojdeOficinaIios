//
//  Settings.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Settings : NSObject
{
  @private
  NSArray*sonido;
  NSArray*sonidoStrings;
    
    NSArray*ClimaImagen;
    NSArray*ActivarClimaImagenStrings;
    
}

@property (nonatomic, assign) int hora;
@property (nonatomic, assign) BOOL vibrar;
@property (nonatomic, assign) BOOL activado;
@property (nonatomic, assign) float volumen;
@property (nonatomic, assign) float sonidoIndex;
@property (nonatomic, assign) int DespertarseMinutes;
@property (nonatomic, assign) int diaMascara;
@property (nonatomic, assign) int offset;
@property (nonatomic, assign) double latitud;
@property (nonatomic, assign) double longitud;
@property (nonatomic, assign) BOOL Clima;
@property (nonatomic, assign) BOOL modo;
@property (nonatomic, assign) BOOL ActivarClimaImagen;



+(Settings*)sharedSettings;
-(void)archive;
-(NSArray*)getSonidoStrings;
-(NSArray*)getWeeeksDaysStrings;
-(NSString*)DespertarseStringForInt:(int)minutes;
-(NSURL*)urlForSonidos:(int)index;
-(NSString*)fileNameForSonido:(int)index;

-(NSArray*)getClimaStrings;
-(NSArray*)getActivarClimaImagenStrings;
-(NSURL*)urlForActivarClimaImagen:(int)index;
-(NSString*)fileNameForActivarClimaImagen:(int)index;

-(bool)on;

- (void)initTransientActivarImagenClima;
@end
