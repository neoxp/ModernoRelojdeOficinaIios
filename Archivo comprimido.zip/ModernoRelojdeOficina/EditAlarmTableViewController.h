//
//  EditAlarmTableViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 27/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sonidosViewController.h"
#import "Settings.h"
#import "insist.h"

#import <AudioToolbox/AudioToolbox.h>

@class sonidosViewController;

@protocol ajustesViewControllerDelegate;

@class SonidoViewController;
@interface EditAlarmTableViewController : UITableViewController<UITextViewDelegate,UINavigationControllerDelegate,
UIImagePickerControllerDelegate, NSURLConnectionDelegate>{
    id delegateAjuste;
    
    NSArray*sounds;
    NSArray*soundStrings;
    
    NSDate*HorasYminutos;
    
    IBOutlet UILabel *response;
    NSMutableData *_responseData;
}



@property (nonatomic, assign) int time;
@property (nonatomic, assign) BOOL vibrate;
@property (nonatomic, assign) float volume;
@property (nonatomic, assign) float soundIndex;

@property NSUserDefaults *userDefaults;

@property (strong, nonatomic) sonidosViewController *detailViewController;


-(void)archive;
-(NSArray*)getSoundStrings;
-(NSArray*)getTimeStrings;
-(NSString*)snoozeStringForInt:(int)minutes;
-(NSURL*)urlForSound:(int)index;
-(NSString*)fileNameForSound:(int)index;

-(bool)on;

// hora 1
@property (nonatomic, retain) IBOutlet UITableViewCell*EditAlarma1led1Cell;
@property (nonatomic, retain) IBOutlet UISwitch*Editaarla1CellSwitch;
@property (nonatomic, retain) IBOutlet UITableViewCell*EditAlarma1dCell;

@property (nonatomic, retain) IBOutlet UILabel*lblhoraAlarmaedit1;

@property (nonatomic, retain) IBOutlet UIDatePicker*dataPMAMHORA;




// SONIDO ALARMA


@property (nonatomic, retain) IBOutlet UILabel*lblSopnido;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;




- (void)sonidoViewController: (SonidoViewController *)controller
             didSelectSonido:(NSString *)sonido;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil timeViewControllerNibName:(NSString*)aName;

- (IBAction)BtnSave:(id)sender;
- (IBAction)EditAlama:(id)sender;


@property (nonatomic, retain) id delegateAjuste;

@property (strong, nonatomic) id detailItem;


@end

@protocol ajustesViewControllerDelegate

- (void) metodoAjuste;

@end
