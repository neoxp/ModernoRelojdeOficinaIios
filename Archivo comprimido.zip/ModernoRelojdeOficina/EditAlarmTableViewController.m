//
//  EditAlarmTableViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 27/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "EditAlarmTableViewController.h"
#import "sonidosViewController.h"
#import "Settings.h"
#import "insist.h"


@interface EditAlarmTableViewController (){}

- (void)configureView;
@end


@implementation EditAlarmTableViewController
{
    NSArray *sonidos;
    NSUInteger indiceSeleccionado;
}



// EDIT ALARMA
@synthesize EditAlarma1led1Cell, Editaarla1CellSwitch, EditAlarma1dCell, lblhoraAlarmaedit1, dataPMAMHORA;


// SONIDO ALARMA
@synthesize lblSopnido, detailDescriptionLabel;






- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad{
    
    [super viewDidLoad];
    
   // EDIT ALARMA
    
    [Editaarla1CellSwitch setOn:NO];
    
    lblhoraAlarmaedit1.textColor = [UIColor redColor];
    dataPMAMHORA.enabled = YES;
    
   
      // SONIDO ALARMA
    lblSopnido.textColor = [UIColor blackColor];
    detailDescriptionLabel.textColor = [UIColor redColor];
    



}


-(IBAction)BtnSave:(id)sender{
    
    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:@"Sonidos"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSLog(@"Guardamos los datos...");
    
    NSUserDefaults *datos = [NSUserDefaults standardUserDefaults];
    
    
    [datos setObject:detailDescriptionLabel.text forKey:@"Sonidos"];
    
    
    
    lblhoraAlarmaedit1.text = [[NSString alloc] initWithData:_responseData encoding:NSUTF8StringEncoding];
    lblhoraAlarmaedit1.text = [[NSString alloc] initWithData:_responseData encoding:NSUTF8StringEncoding];
    
    lblSopnido.text = [[NSString alloc] initWithData:_responseData encoding:NSUTF8StringEncoding];

    detailDescriptionLabel.text = [[NSString alloc] initWithData:_responseData encoding:NSUTF8StringEncoding];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Actions



-(NSArray *)formatCurrentDateTimeForTimeZone {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
    NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_EN_POSIX"];
    NSTimeZone *localTimeZone = [NSTimeZone timeZoneWithAbbreviation:localTimeZone];
    [dateFormatter setLocale:posix];
    [dateFormatter setDateFormat:@"EEEE MMMM dd y"];
    [dateFormatter setTimeZone:localTimeZone];
    [timeFormatter setLocale:posix];
    [timeFormatter setDateFormat:@"HH:MM:ss a"];
    [timeFormatter setTimeZone:localTimeZone];
    
    NSDate *now = [NSDate date];
    NSString *date = [dateFormatter stringFromDate:now];
    NSString *time = [timeFormatter stringFromDate:now];
    
    NSArray *formattedDateAndTime = @[date, time];
    return formattedDateAndTime;
}



- (IBAction)EditAlama:(id)sender{
    

    if (Editaarla1CellSwitch.on){
      
    
        lblhoraAlarmaedit1.textColor = [UIColor redColor];

        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
        NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_EN_POSIX"];
        NSTimeZone *localTimeZone = [NSTimeZone timeZoneWithAbbreviation:localTimeZone];
        [dateFormatter setLocale:posix];
        [dateFormatter setDateFormat:@"EEEE MMMM dd y"];
        [dateFormatter setTimeZone:localTimeZone];
        [timeFormatter setLocale:posix];
        [timeFormatter setDateFormat:@"HH:MM:ss a"];
        [timeFormatter setTimeZone:localTimeZone];
        
        NSDate *now = [NSDate date];
        NSString *date = [dateFormatter stringFromDate:now];
        NSString *time = [timeFormatter stringFromDate:now];
        
        NSArray *formattedDateAndTime = @[date, time];
      
        dataPMAMHORA.exclusiveTouch = timezone = self.lblhoraAlarmaedit1.text =[NSString stringWithFormat:@"05:45 AM MONDAY"];
        
 
        
        Editaarla1CellSwitch.enabled = Editaarla1CellSwitch.enabled = YES;
        Editaarla1CellSwitch.alpha = Editaarla1CellSwitch.alpha = .5;
        
        
    }else{
        lblhoraAlarmaedit1.textColor = [UIColor redColor];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
        NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_EN_POSIX"];
        NSTimeZone *localTimeZone = [NSTimeZone timeZoneWithAbbreviation:localTimeZone];
        [dateFormatter setLocale:posix];
        [dateFormatter setDateFormat:@"EEEE MMMM dd y"];
        [dateFormatter setTimeZone:localTimeZone];
        [timeFormatter setLocale:posix];
        [timeFormatter setDateFormat:@"HH:MM:ss a"];
        [timeFormatter setTimeZone:localTimeZone];
        
        NSDate *now = [NSDate date];
        NSString *date = [dateFormatter stringFromDate:now];
        NSString *time = [timeFormatter stringFromDate:now];
        
        NSArray *formattedDateAndTime = @[date, time];
        
        dataPMAMHORA.exclusiveTouch = timeFormatter = self.lblhoraAlarmaedit1.text = [NSString stringWithFormat:@"10:15 PM WENSDAY"];
        
        
  
        

        Editaarla1CellSwitch.enabled = Editaarla1CellSwitch.enabled = NO;
        Editaarla1CellSwitch.alpha = Editaarla1CellSwitch.alpha = .5;
       }
    
        if (Editaarla1CellSwitch.isHidden){
        lblhoraAlarmaedit1.textColor = [UIColor greenColor];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
        NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_EN_POSIX"];
        NSTimeZone *localTimeZone = [NSTimeZone timeZoneWithAbbreviation:localTimeZone];
        [dateFormatter setLocale:posix];
        [dateFormatter setDateFormat:@"EEEE MMMM dd y"];
        [dateFormatter setTimeZone:localTimeZone];
        [timeFormatter setLocale:posix];
        [timeFormatter setDateFormat:@"HH:MM:ss a"];
        [timeFormatter setTimeZone:localTimeZone];
        
        NSDate *now = [NSDate date];
        NSString *date = [dateFormatter stringFromDate:now];
        NSString *time = [timeFormatter stringFromDate:now];
        
        NSArray *formattedDateAndTime = @[date, time];
        
        dataPMAMHORA.exclusiveTouch = timeFormatter = self.lblhoraAlarmaedit1.text = [NSString stringWithFormat:@"20:45 PM SATURDAY"];
        
     
            

        Editaarla1CellSwitch.enabled = Editaarla1CellSwitch.enabled = NO;
        Editaarla1CellSwitch.alpha = Editaarla1CellSwitch.alpha = .5;
    }
    
    

    [delegateAjuste metodoAjuste];
}



@end
