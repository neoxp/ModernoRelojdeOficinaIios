//
//  Turismo.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeWorld : NSObject

@property (strong, nonatomic)NSString *lbltimewordl;
@property (strong, nonatomic)NSString *lblPM;
@property (strong, nonatomic)NSString *lblAM;
@property (strong, nonatomic)NSString *Country;


- (id)initWithlbltimewordl:(NSString *)albltimewordl
                     lblAM:(NSString *)alblAM
                     lblPM:(NSString *)alblPM
               Country:(NSString *)aCountry;



- (id)initWithDictionary:(NSDictionary *)dic;

@end
