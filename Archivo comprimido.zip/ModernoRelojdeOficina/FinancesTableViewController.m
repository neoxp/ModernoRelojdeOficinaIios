//
//  FinancesTableViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "FinancesTableViewController.h"
#import "FinancesCell.h"
#import "Finances.h"

#import "AFHTTPRequestOperationManager.h"
#import "UIImageView+AFNetworking.h"



#import "AjustesViewController.h"
#import "FinancesTableViewController.h"
#import "FinancesCell.h"


@interface FinancesTableViewController ()

@property NSMutableArray *objects;
@end

@implementation FinancesTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    
}


- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


-(IBAction)UpdateFile:(id)sender{
    if (!self.objects) {
        self.objects = [[NSMutableArray alloc] init];
    }
    [self.objects insertObject:[NSDecimalNumber decimalNumberWithMantissa:-12000 exponent:2 isNegative:YES] atIndex:0];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}



#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}


- (FinancesCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FinancesCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    NSDecimalNumber *object = self.objects[indexPath.row];
    cell.LblFinancesWorld.text = [object description];
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.objects removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
    }
}


@end
