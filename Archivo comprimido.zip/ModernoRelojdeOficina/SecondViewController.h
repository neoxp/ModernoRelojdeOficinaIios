//
//  SecondViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>

@interface SecondViewController : UIViewController


@property (strong, nonatomic) IBOutlet UILabel *TitleLbl;
@property (strong, nonatomic) IBOutlet UITextView *TextCreditsView;


@end

