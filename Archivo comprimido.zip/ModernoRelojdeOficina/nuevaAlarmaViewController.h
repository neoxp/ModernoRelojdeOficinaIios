//
//  nuevaAlarmaViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 08/04/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Alarma.h"
#import "sonidosViewController.h"
#import "Settings.h"
#import "insist.h"
#import "addAlarmaCell.h"

@class Alarma;
@class editarTextoViewController;
@class sonidosViewController;

@interface nuevaAlarmaViewController : UITableViewController<UITextFieldDelegate, UITableViewDataSource, UITableViewDataSource, UIPickerViewDelegate,UIPickerViewDataSource>
{
    Alarma *editingAlarma;
    
    editarTextoViewController *editarVC;
    sonidosViewController *sonidosVC;
        
    IBOutlet UIDatePicker *datePicker;
    IBOutlet UITableView *uiTableView;
    
    UINavigationItem *navigationItem;
    NSString *tituloVentana;
    NSMutableArray *arrayAlarmas;
    
    IBOutlet UITableViewCell *celdaEstado;
    
     IBOutlet UITableViewCell *celdaEstadoaddAlarmaCell;
}

-(void)guardar;
-(void)cancelar;
-(void)preservarHora;
-(IBAction)cambiarEstado:(id)sender;


@property (nonatomic, weak) IBOutlet UIDatePicker *PikerTime;

@property (nonatomic, weak) IBOutlet UISwitch *enableSwich;

@property (nonatomic, weak) IBOutlet UIStepper *plusButton;

@property (nonatomic, weak) IBOutlet UIStepper *minusButton;

@property (nonatomic, weak) IBOutlet UILabel *LblTime;





@property (nonatomic)IBOutlet UITableView *uiTableView;
@property (nonatomic)NSMutableArray *arrayAlarmas;
@property (nonatomic)Alarma *editingAlarma;
@property (nonatomic)IBOutlet UIDatePicker *datePicker;
@property (nonatomic)NSString *tituloVentana;
@property (nonatomic)UITableViewCell *celdaEstado;
@property (nonatomic)UITableViewCell *celdaEstadoaddAlarmaCell;
@end
