//
//  CatalanCell.h
//  MultiJugadoresJuegodelHorcado
//
//  Created by Hackermaster on 09/05/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeClockWorldCell : UITableViewCell
@property (nonatomic, weak) IBOutlet UILabel *LblTimeClockWorld;

@end
