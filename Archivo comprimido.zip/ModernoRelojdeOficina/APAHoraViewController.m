//
//  APAHoraViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import "APAHoraViewController.h"
#import "Alarma.h"
#import "Settings.h"
#import "insist.h"
#import "XMLReader.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

#import "YahooWeather.h"
#import "XMLReader.h"
#import "insist.h"

#import "RZTelprompt.h"
#import "CustomAnnotation.h"
#import <MapKit/MapKit.h>
#import "CoreLocationController.h"


@interface APAHoraViewController ()

-(void)climaWetheer;
-(void)setTappedCityTimer;

@property (nonatomic, weak) IBOutlet UILabel *MonLbl;
@property (nonatomic, weak) IBOutlet UILabel *MarLbl;
@property (nonatomic, weak) IBOutlet UILabel *MierLbl;
@property (nonatomic, weak) IBOutlet UILabel *JueLbl;
@property (nonatomic, weak) IBOutlet UILabel *VieLbl;
@property (nonatomic, weak) IBOutlet UILabel *SablBL;
@property (nonatomic, weak) IBOutlet UILabel *DomLbl;


// ON , OFF I IMAGEN ON I OFF //
@property (nonatomic, weak) IBOutlet UIImageView *OnImg;
@property (nonatomic, weak) IBOutlet UIImageView *OffImg;
@property (nonatomic, weak) IBOutlet UILabel *enabledLabel;


// HORA , AM I PM //
@property (nonatomic, weak) IBOutlet UILabel *AmLabel;
@property (nonatomic, weak) IBOutlet UILabel *PmLabel;
@property (nonatomic, weak) IBOutlet UILabel *timeLabel;


// DIA MES Y ANY //
@property (nonatomic, weak) IBOutlet UILabel *dateLabel;

// CLIMA //
@property (nonatomic, weak) IBOutlet UIImageView *ClimaImagen;
@property (nonatomic, weak) IBOutlet UILabel *ClimaLabel;


// MAPA LOCALIZACION //


@property (nonatomic, retain) IBOutlet UILabel *LbLCity;
@property (nonatomic, retain) IBOutlet UILabel *LblLatitud;
@property (nonatomic, retain) IBOutlet UILabel *LbLong;


@property (nonatomic, retain) IBOutlet MKMapView *Localizacion;


@property (nonatomic) MKMapPoint *point;

@property(nonatomic, strong)NSString *timeZone;

@property(nonatomic, strong)NSTimer * timer;

@end

@implementation APAHoraViewController

@synthesize LblLatitud,LbLong,LbLCity;

@synthesize Localizacion;


-(void)setOnHidden:(BOOL)hidden
{
    self.enabledLabel.hidden = hidden;
    self.enabledLabel.enabled = YES;
}

-(bool)on{
    
    if([[UIDevice currentDevice].model isEqualToString:@"ON"])
    {
        
        _OnImg.image = [UIImage imageNamed:@"ledsverde.png"];
        self.enabledLabel.text = @"ON";
         return _OnImg && _OffImg && _enabledLabel;
    }
    else if([[UIDevice currentDevice].model isEqualToString:@"ON"])
    {
        
        _OffImg.image = [UIImage imageNamed:@"ledrojo.png"];
        self.enabledLabel.text = @"OFF";
         return _OnImg && _OffImg && _enabledLabel;
    }

    return _OnImg && _OffImg && _enabledLabel;
}


-(NSDateComponents*)componentsFromDate:(NSDate*)date
{
    return [[NSCalendar autoupdatingCurrentCalendar]
            components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit fromDate:date];
}

-(void)setTimeFromComponents:(NSDateComponents*)components
{
    insist (components);
    
    int hour = [components hour];
    
    if (hour < 1)
        hour = 12;
    else if (hour > 12)
        hour -= 12;
    
    _timeLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d", hour, [components minute], [components second]];
    
}

- (void)update:(CLLocation *)location {
    self.LbLCity.text = @"City: " , annotationPoint.description;
    self.LblLatitud.text= [NSString stringWithFormat:@"Lat:", [location coordinate].latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Long:-", [location coordinate].longitude];
    
   
}

- (void)locationError:(NSError *)error {
    self.LblLatitud.text = [error description];
    self.LbLong.text = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.MonLbl setEnabled:YES];
    [self.MarLbl setEnabled:YES];
    [self.MierLbl setEnabled:YES];
    [self.JueLbl setEnabled:YES];
    [self.VieLbl setEnabled:YES];
    [self.SablBL setEnabled:YES];
    [self.DomLbl setEnabled:YES];

    
    self.enabledLabel.text = @"ON";
    
 
        
        if ([days count] != [days count])
        {
            
             if([[days description].description  isEqualToString:@"LUN"])
            {
                  days = self.MonLbl.text = @"LUN";
            }
            if([[days description].description  isEqualToString:@"MAR"])
            {
                  days = self.MarLbl.text = @"MAR";
            }
            if([[days description].description  isEqualToString:@"MIE"])
            {
                 days = self.MierLbl.text = @"MIE";
            }
            if([[days description].description  isEqualToString:@"JUE"])
            {
                 days = self.JueLbl.text = @"JUE";
            }
            if([[days description].description  isEqualToString:@"VIE"])
            {
                  days = self.JueLbl.text = @"VIE";
            }
            
             if([[days description].description  isEqualToString:@"SAB"])
            {
                  days = self.SablBL.text = @"SAB";
            }
             if([[days description].description  isEqualToString:@"DOM"])
            {
              days = self.DomLbl.text = @"DOM";
            }
       
    }

    
    self.LbLCity.text = @"City: Tortosa ES" , mapView.showsPointsOfInterest;
    self.LblLatitud.text= [NSString stringWithFormat:@"Lat:37,785834", [delegate coordinate].latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Long:-122,406417", [delegate coordinate].longitude];

    
    locManager = [[CLLocationManager alloc]init];
    locManager.delegate = self;
    locManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    [locManager startUpdatingLocation];

    
    [self setTappedCityTimer];
    [self climaWetheer];
    [self enabledLabelhone];
    [self WeeKSdays];
 
    
    AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
   
    Localizacion.showsUserLocation = YES;
    
    Localizacion.delegate = self;
    
    
    [self.Localizacion showsPointsOfInterest];
    
    [self.Localizacion setZoomEnabled:YES];
    
    
    [self.Localizacion setZoomEnabled:YES];
    
    
    self.locationController = [[CoreLocationController alloc] init];
    self.locationController.delegate = self;
    [self.locationController.locationManager startUpdatingLocation];
    
    
    NSArray *WeeksDays = [@[self.MonLbl, self.MarLbl, self.MierLbl, self.JueLbl, self.view, self.SablBL,self.DomLbl]mutableCopy];
    NSMutableArray *unselectedCities = [NSMutableArray array];
    
    for (UILabel *Dias in WeeksDays) {
        [unselectedCities setArray:WeeksDays];
        NSArray *WeeksDays = [@[self.MonLbl, self.MarLbl, self.MierLbl, self.JueLbl, self.view, self.SablBL,self.DomLbl]mutableCopy];
        NSMutableArray *unselectedCities = [NSMutableArray array];
        
    }


}


- (void) WeeKSdays{

    NSArray *WeeksDays = [@[self.MonLbl, self.MarLbl, self.MierLbl, self.JueLbl, self.view, self.SablBL,self.DomLbl]mutableCopy];
    NSMutableArray *unselectedCities = [NSMutableArray array];
    
    for (UILabel *Dias in WeeksDays) {
        [unselectedCities setArray:WeeksDays];
        NSArray *WeeksDays = @[self.MonLbl, self.MarLbl, self.MierLbl, self.JueLbl, self.view, self.SablBL,self.DomLbl];
        NSMutableArray *unselectedCities = [NSMutableArray array];
        
    }
    
}

- (void)enabledLabelhone {
    
  
     if([[UIDevice currentDevice].model isEqualToString:@"OFF"])
    {
        
        _OffImg.image = [UIImage imageNamed:@"ledrojo.png"];
        self.enabledLabel.text = @"OFF";
       
    }
    
    if([[UIDevice currentDevice].model isEqualToString:@"ON"])
    {
        
        _OnImg.image = [UIImage imageNamed:@"ledsverde.png"];
        self.enabledLabel.text = @"ON";
        
    }
 
}

-(void)setDayFromComponents:(NSDateComponents*)components{
    NSArray*symbols = [dateFormatter shortWeekdaySymbols];
    insist (symbols);
    
    
    for (int i = 0; i < [days count]; i++)
    {
        UILabel*day = [days objectAtIndex:i];
        
        if ([symbols count] != [days count])
        {
            day.hidden = YES;
            continue;
        }
        day.text = [symbols objectAtIndex:_MonLbl && _MarLbl && _MierLbl && _JueLbl && _VieLbl && _SablBL && _DomLbl];
        day.text = [symbols objectAtIndex:_AmLabel && _PmLabel];
    }
}

-(BOOL)isPM:(NSDateComponents*)components
{
    return [components hour] > 12 || ([components hour] == 12 && ([components minute] || [components second]));
}

-(void)setAMPMFromComponents:(NSDateComponents*)components
{
    insist (dateFormatter && components);
    
    _AmLabel.text = [dateFormatter AMSymbol];
    _PmLabel.text = [dateFormatter PMSymbol];
    
    if ([self isPM:components])
    {
        _AmLabel.enabled = YES;
        _PmLabel.alpha = 1.0;
    }
    else
    {
        _AmLabel.alpha = 1.0;
        _PmLabel.enabled = YES;
    }
}



-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    UIAlertView *errorAlert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"There was an error retrieving your location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [errorAlert show];
    NSLog(@"Error: %@",error.description);
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *crnLoc = [locations lastObject];
    MKMultiPoint *point = [annotationPoint description];
    
    self.LbLCity.text = @"City: " , locations.description;
    self.LblLatitud.text= [NSString stringWithFormat:@"Lat:", [delegate coordinate].latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Long:-", [delegate coordinate].longitude];
    
    
}





- (void)mapView:(MKMapView *)Localizacion didUpdateUserLocation:(MKUserLocation *)userLocation{
    self.Localizacion.centerCoordinate = userLocation.location.coordinate;
}

- (void)zoomIn: (id)sender
{
    MKUserLocation *userLocation = Localizacion.userLocation;
    MKCoordinateRegion region =
    MKCoordinateRegionMakeWithDistance (
                                        userLocation.location.coordinate, 50, 50);
    [Localizacion setRegion:region animated:YES];
    [self.Localizacion showsUserLocation];
    
    self.LbLCity.text = @"City: " , userLocation.description;
    self.LblLatitud.text= [NSString stringWithFormat:@"Lat:", [userLocation coordinate].latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Long:-", [userLocation coordinate].longitude];

    
    [self.Localizacion showsPointsOfInterest];
    
    [self.Localizacion setZoomEnabled:YES];
}




- (void) changeMapType: (id)sender
{
    if (Localizacion.mapType == MKMapTypeSatellite)
        Localizacion.mapType = MKMapTypeSatellite;
    else
        Localizacion.mapType = MKMapTypeSatellite;
}


-(void)climaWetheer{
 
    self.ClimaLabel.text = [NSString stringWithFormat:@"Parcialmente nublado, Probabilidad de lluvia es del :20% - Tempreratura Actual 19ºC - Max de 28 C - Min 15º C"];
    gettingWoeid = YES;
    
}


-(void)setTappedCityTimer {
    [self.timer invalidate];
    self.timer = nil;
    
    [self unhighlightDeselected];
    
    [self setDateTimeLabelsWithTimeZone];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(setDateTimeLabelsWithTimeZone) userInfo:nil repeats:YES];
}

-(void)setDateTimeLabelsWithTimeZone {
    NSArray *dateAndTime = [self formatCurrentDateTimeForTimeZone];
    self.timeLabel.text = dateAndTime[1];
    self.dateLabel.text = dateAndTime[0];
}

-(NSArray *)formatCurrentDateTimeForTimeZone {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
    NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_EN_POSIX"];
    NSTimeZone *localTimeZone = [NSTimeZone timeZoneWithAbbreviation:self.timeZone];
    [dateFormatter setLocale:posix];
    [dateFormatter setDateFormat:@"EEEE MMMM dd y"];
    [dateFormatter setTimeZone:localTimeZone];
    [timeFormatter setLocale:posix];
    [timeFormatter setDateFormat:@"HH:MM:ss a"];
    [timeFormatter setTimeZone:localTimeZone];
    
    NSDate *now = [NSDate date];
    NSString *date = [dateFormatter stringFromDate:now];
    NSString *time = [timeFormatter stringFromDate:now];
    
    NSArray *formattedDateAndTime = @[date, time];
    return formattedDateAndTime;
}



-(void)unhighlightDeselected {
    NSArray *WeeksDays = [@[self.MonLbl, self.MarLbl, self.MierLbl, self.JueLbl, self.view, self.SablBL,self.DomLbl]mutableCopy];
    NSMutableArray *unselectedCities = [NSMutableArray array];
    
    for (UILabel *Dias in WeeksDays) {
            [unselectedCities setArray:WeeksDays];
        NSArray *WeeksDays = [@[self.MonLbl, self.MarLbl, self.MierLbl, self.JueLbl, self.view, self.SablBL,self.DomLbl]mutableCopy];
        NSMutableArray *unselectedCities = [NSMutableArray array];
      
    }
}

@end

