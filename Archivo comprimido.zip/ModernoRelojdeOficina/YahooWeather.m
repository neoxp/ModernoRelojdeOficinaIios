//
//  YahooWeather.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import "YahooWeather.h"
#import "XMLReader.h"
#import "insist.h"

@implementation YahooWeather


#define TIMEOUT_SECONDS (60*3)

-(id)initWithYahooWeatherDelegate:(id)aDelegate
{
  self = [super init];
  insist (self);
  delegate = aDelegate;
  
  fetcher = [[HTTPFetcher alloc] initWithDelegate:self];
  insist (fetcher);
  return self;
}

-(void) dealloc
{
  [fetcher autoContentAccessingProxy];
  [super autoContentAccessingProxy];
}

-(void)goWithLatitude:(double)lat longitude:(double)lon;
{

  insist (fetcher);
  
  [fetcher go:
   [NSString stringWithFormat:@"http://where.yahooapis.com/api.worldweatheronline.com/premium/v1/weather.ashx?q=Barcelona&format=XML&num_of_days=5&tp=24Hours&showlocaltime=Yes&key=e2zzhfpw9kbmms9s2a88mf99-",
               lat, lon]withTimeout:TIMEOUT_SECONDS];
   
  gettingWoeid = YES;
}
 

- (void)didFinish:(HTTPFetcher*)aFetcher withData:(NSData*)data
{
  if (gettingWoeid)
  {

    NSDictionary*dict = [XMLReader dictionaryForXMLString:[aFetcher stringFromData:data] error:nil];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    dict = [dict objectForKey:@"ResultSet"];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    dict = [dict objectForKey:@"Result"];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    NSString*woeid = [dict objectForKey:@"woeid"];
    if (!woeid)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }

    gettingWoeid = NO;
    [fetcher go:[NSString stringWithFormat:@"http://weather.yahooapis.com/forecastrss?w=%@", woeid] withTimeout:TIMEOUT_SECONDS];
  }
  else
  {

    NSDictionary*dict = [XMLReader dictionaryForXMLString:[aFetcher stringFromData:data] error:nil];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    dict = [dict objectForKey:@"rss"];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    dict = [dict objectForKey:@"channel"];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    NSDictionary*units = [dict objectForKey:@"yweather:units"];
    if (!units)
    { 
      [delegate weather:self gotWeather:nil];
      return;
    }
    NSString*corf = [units objectForKey:@"@temperature"];
    if (!corf)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    dict = [dict objectForKey:@"item"];
    if (!dict)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    NSDictionary*condition = [dict objectForKey:@"yweather:condition"];
    if (!condition)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    NSString*text = [condition objectForKey:@"@text"];
    if (!text)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }
    NSString*temp = [condition objectForKey:@"@temp"];
    if (!temp)
    {
      [delegate weather:self gotWeather:nil];
      return;
    }

      
    [delegate weather:self gotWeather:[NSString stringWithFormat:@"%@ %@ %@", temp, corf, text]];
    return;

  }
}

- (void)didFail:(HTTPFetcher*)fetcher withError:(NSString*)error
{
  [delegate weather:self gotWeather:nil];
}

- (void)didTimeout:(HTTPFetcher*)fecher
{
  [delegate weather:self gotWeather:nil];
}

@end
