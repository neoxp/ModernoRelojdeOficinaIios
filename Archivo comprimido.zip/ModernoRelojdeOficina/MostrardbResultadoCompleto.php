<table border="1" cellspacing=1 cellpadding=2 style="font-size: 8pt"><tr>
<td><font face="verdana"><b>id</b></font></td>
<td><font face="verdana"><b>Name</b></font></td>
<td><font face="verdana"><b>Gastronomi</b></font></td>
<td><font face="verdana"><b>Ranking</b></font></td>
<td><font face="verdana"><b>location</b></font></td>
<td><font face="verdana"><b>lat</b></font></td>
<td><font face="verdana"><b>lng</b></font></td>
</tr>

<?php
    
    $link = mysqli_connect("mysql.webcindario.com", "lugaresdeinteres", "admin1234");
    or die ("Error al conectar a la base de datos.");
    @mysql_select_db("lugaresdeinteres", $link)
    or die ("Error al conectar a la base de datos.");
    
    $query = "SELECT `id`, `Name`, `Gastronomi`, `Ranking`, `location`, `lat`, `lng`, `ruta` FROM `lugares` WHERE id = id";
    $result = mysql_query($query);
    $numero = 0;
    while($row = mysql_fetch_array($result))
    {
        echo "<tr><td width=\"25%\"><font face=\"verdana\">" .
	    $row["id"] . "</font></td>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["Name"] . "</font></td>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["Gastronomi"] . "</font></td>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["fecha"]. "</font></td></tr>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["Ranking"]. "</font></td></tr>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["location"]. "</font></td></tr>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["lat"]. "</font></td></tr>";
        
        echo "<td width=\"25%\"><font face=\"verdana\">" .
	    $row["lng"]. "</font></td></tr>";
        
        $numero++;
    }
    echo "<tr><td colspan=\"15\"><font face=\"verdana\"><b>Número: " . $numero .
    "</b></font></td></tr>";
    
    mysql_free_result($result);
    mysql_close($link);
    ?>
</table>