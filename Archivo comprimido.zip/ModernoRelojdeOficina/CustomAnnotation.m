//
//  CustomAnnotation.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "CustomAnnotation.h"

@implementation CustomAnnotation

- (id)initWithCoordinate:(CLLocationCoordinate2D) c {
    self.coordinate = c;
    self.title = @"Titulo";
    self.subtitle = @"Subtitulo";
    return self;
}

-(id)initWithCoordinate:(CLLocationCoordinate2D)c withName:(NSString*)name
            withAddress:(NSString*)address {
    self = [super init];
    if (self) {
        self.coordinate = c;
        self.title = name;
        self.subtitle = address;
    }
    return self;
}

@end
