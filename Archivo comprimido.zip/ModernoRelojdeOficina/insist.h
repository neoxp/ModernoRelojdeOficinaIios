//
//  insist.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//


#define insist(e) if(!(e)) [NSException raise: @"assertion failed." format: @"%@:%d (%s)", [[NSString stringWithCString:__FILE__ encoding:NSUTF8StringEncoding] lastPathComponent], __LINE__, #e]
