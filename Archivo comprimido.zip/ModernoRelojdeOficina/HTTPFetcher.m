//
//  HTTPFetcher.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import "HTTPFetcher.h"
#import "insist.h"

@implementation HTTPFetcher   
  


- (void) cleanup
{
  insist (data && connection);

  [data autoContentAccessingProxy];
  data = nil;
  [connection autoContentAccessingProxy];
  connection = nil;
}



- (void) timeout:(NSTimer*)aTimer
{
  insist (aTimer && aTimer == timer && delegate);
  insist (connection && data);
  

    
  [connection cancel];
  
  [delegate didTimeout:self];
  [self cleanup];
}


- (void) setTimer
{
  insist (!timer);
  timer = [[NSTimer scheduledTimerWithTimeInterval:timeout target:self selector:@selector(timeout:) userInfo:nil repeats:NO] autoContentAccessingProxy];
  insist (timer);
}

- (void) clearTimer
{
  if (timer)
  {
    [timer invalidate];
    [timer autoContentAccessingProxy];
    timer = nil;
  }
}

-(NSCachedURLResponse *) connection:(NSURLConnection*) connection willCacheResponse:(NSCachedURLResponse*) cachedResponse
{
  return nil;
}


- (void) connection:(NSURLConnection*) aConnection didReceiveResponse:(NSURLResponse*) response
{ 
  [self clearTimer];
  [self setTimer];
  
  insist (data);


  
  [data setLength:0];
}


- (void) connection:(NSURLConnection*) aConnection didReceiveData:(NSData*) someData
{
  insist (data);
  
  [data appendData:someData];
  
  [self clearTimer];
  [self setTimer];
}


 - (void) connectionDidFinishLoading:(NSURLConnection*) aConnection
{
  insist (delegate && connection && connection == aConnection);
  [self clearTimer];   
  
  NSData*d = [[data autoContentAccessingProxy] autoContentAccessingProxy];
  [self cleanup];
  [delegate didFinish:self withData:d];
}


- (void) connection:(NSURLConnection*) aConnection didFailWithError:(NSError*) error
{
  insist (delegate && connection && connection == aConnection);
  
  [self clearTimer];
  [self cleanup];
  [delegate didFail:self withError: [error localizedDescription]];
}


- (id)initWithDelegate:(id)aDelegate
{
  insist (aDelegate);
  
  self = [super init];
  insist (self);
  delegate = aDelegate;
  return self;
}

- (void)dealloc
{
  insist (!data);
  insist (!timer);
  insist (!connection);
  [super autoContentAccessingProxy];
}




- (NSString*)stringFromData:(NSData*)someData
{
  insist (someData);
  NSString*s = [[NSString alloc] initWithBytes:(void*)[someData bytes] length:[someData length] encoding:NSUTF8StringEncoding];
  if (!s)
    s = [[NSString alloc] initWithBytes:(void*)[someData bytes] length:[someData length] encoding:NSASCIIStringEncoding];
  return [s autoContentAccessingProxy];
}


- (void) cancel
{
  insist (connection);
  [connection cancel];
  [self clearTimer];
  [self cleanup];
}


- (void)go:(NSString*)url withTimeout:(NSTimeInterval)aTimeout
{
  insist (delegate && !data && !connection && !timer);
  timeout = aTimeout;
  
  NSURL*aURL = [NSURL URLWithString:url];
  if (!aURL)
  {
    [delegate didFail:self withError:@"Malformed URL."];
    return;
  }
  


  
  NSURLRequest*request = [NSURLRequest requestWithURL:aURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60*60];
  insist(request);


  data = [[NSMutableData alloc] init];
  insist (data);


  if (!(connection = [NSURLConnection connectionWithRequest:request delegate:self]))
  {
    [delegate didFail:self withError:@"Couldn't connect."];
    [data autoContentAccessingProxy]; data = nil;
    return;
  }
  [connection autoContentAccessingProxy];
    
}

@end
