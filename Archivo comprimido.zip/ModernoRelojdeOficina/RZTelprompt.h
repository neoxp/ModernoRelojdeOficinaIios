//
//  RZTelprompt.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface RZTelprompt : NSObject

+ (void)callWithString:(NSString*)phoneString;
+ (void)callWithURL:(NSURL*)url;

@end
