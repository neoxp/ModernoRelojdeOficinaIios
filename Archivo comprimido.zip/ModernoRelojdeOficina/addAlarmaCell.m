//
//  addAlarmaCell.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "addAlarmaCell.h"

@implementation addAlarmaCell

@synthesize PikerTime = _PikerTime;
@synthesize plusButton = _plusButton;
@synthesize minusButton = _minusButton;
@synthesize LblTime = _LblTime;
@synthesize enableSwich = _enableSwich;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.PikerTime.date = _PikerTime;
         self.enableSwich.enabled = _enableSwich;
         self.plusButton.enabled = _plusButton;
         self.minusButton.enabled = _minusButton;
         self.LblTime.text = _LblTime;
    }
    return self;
}

-(IBAction)guardar:(id)sender{
    
    if(arrayAlarmas)
    {
        UIAlertView *alerta=[[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Error", @"ErrorCadenaVacia") message:NSLocalizedString(@"El campo titulo es obligatorio.", @"Titulo en blanco") delegate:self cancelButtonTitle:NSLocalizedString(@"Aceptar", @"BotonAceptarError") otherButtonTitles: nil];
        
        [_LblTime setText:[NSString stringWithFormat:@"%d", (int)timezone]];
        self.PikerTime.date = _PikerTime;
        self.enableSwich.enabled = _enableSwich;
        self.plusButton.enabled = _plusButton;
        self.minusButton.enabled = _minusButton;
        [alerta show];
    }
    else
    {
        [self preservarHora];
        
        
        if(arrayAlarmas)
        {
        }
        
        
        [arrayAlarmas addObject:editingAlarma];
        
        
    }
    
}


- (IBAction)valueChanged:(UIStepper *)sender {
    double value = [sender value];
    
    [_LblTime setText:[NSString stringWithFormat:@"%d", (int)value]];
    self.PikerTime.date = _PikerTime;
    self.enableSwich.enabled = _enableSwich;
    self.plusButton.enabled = _plusButton;
    self.minusButton.enabled = _minusButton;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
