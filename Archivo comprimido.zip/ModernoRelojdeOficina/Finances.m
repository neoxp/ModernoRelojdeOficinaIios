//
//  Turismo.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//


#import "Finances.h"

@implementation Finances

- (id)initWithName:(NSString *)aName
           moneyUp:(NSString *)amoneyUp
         moneyDown:(NSString *)amoneyDown{
    self = [super init];
    
    if (self) {
        self.name = aName;
        self.moneyUp = amoneyUp;
         self.moneyDown = amoneyUp;
    }
    
    return self;
}



- (id)initWithDictionary:(NSDictionary *)dic {
    self = [self initWithName:dic[@"name"]  moneyUp:dic[@"moneyUp"]  moneyDown:dic[@"moneyDown"]];
    return self;
}

- (id)init {
    self = [self initWithName:@"Finances" moneyUp:@"+121000" moneyDown:@"-2354"];
    return self;
}



@end
