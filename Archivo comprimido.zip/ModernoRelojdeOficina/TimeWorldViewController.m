//
//  TimeWorldViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//


#import "TimeWorldViewController.h"
#import "TimeClockWorldCell.h"
#import "TimeWorld.h"
#import "TimeWorld.h"
#import "AFHTTPRequestOperationManager.h"
#import "UIImageView+AFNetworking.h"



@interface TimeWorldViewController ()

@property NSMutableArray *objects;
@end

@implementation TimeWorldViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = self.editButtonItem;

    self.detailViewController = (TimeWorldViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
}


- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


-(IBAction)UpdateFile:(id)sender{
    self.objects = [[NSMutableArray alloc] init];


NSDictionary *tempDict = [NSTimeZone abbreviationDictionary];
NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneDataVersion];
NSString* timeZoneName;

for(NSString *str in tempDict){
    sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:str];
    timeZoneName = [sourceTimeZone localizedName:NSTimeZoneNameStyleStandard locale:[NSLocale currentLocale]];
    NSLog(@"%@ --- %@", timeZoneName,sourceTimeZone);
    
    [self.objects insertObject:[NSTimeZone localTimeZone] atIndex:0];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    
        }

    NSLog(@"timeZoneName : %@", timeZoneName);
}




#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}


- (TimeClockWorldCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TimeClockWorldCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    NSDictionary *tempDict = [NSTimeZone abbreviationDictionary];
    NSTimeZone* sourceTimeZone = [NSTimeZone systemTimeZone];
    NSString* timeZoneName;
    
    for(NSString *str in tempDict){
        sourceTimeZone = self.objects[indexPath.row];
        cell.LblTimeClockWorld.text = [sourceTimeZone description];
  
        sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:str];
        timeZoneName = [sourceTimeZone localizedName:NSTimeZoneNameStyleShortGeneric locale:[NSLocale autoupdatingCurrentLocale]];
        
        
    }
    
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}



@end
